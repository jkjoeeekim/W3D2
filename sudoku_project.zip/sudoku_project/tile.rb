class Tile
  attr_reader :value, :given

  def initialize(value)
    @value = value
    @given = value.positive? ? true : false
  end
end
