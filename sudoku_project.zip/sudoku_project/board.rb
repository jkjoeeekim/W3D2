class Board
  class << self
    def from_file
      random = (1..3).to_a.sample
      puzzle = File.readlines("puzzles/sudoku#{random}.txt").map(&:chomp)
    end
  end

  attr_reader :grid, :puzzle

  def initialize
    @puzzle = Board.from_file
    @grid = Array.new(@puzzle.length) { Array.new(@puzzle[0].length) }
  end
end

board = Board.new
p board.grid
p board.puzzle
